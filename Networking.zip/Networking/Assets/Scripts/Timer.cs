using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class Timer : NetworkBehaviour
{
    [SerializeField] private TextMeshProUGUI TimerText;
    public NetworkVariable<float> TimeLeft;
    public bool StartTimer;
    private UI MyUI;
    private SpawnEnemy EnemySpawn;

    private void Start()
    {
        TimerText.text = "TIME: " + TimeLeft.Value.ToString();
        MyUI = GameObject.Find("GameCanvas").GetComponent<UI>();
        EnemySpawn = GameObject.FindAnyObjectByType<SpawnEnemy>();
        TimeLeft.OnValueChanged += (Old,New) =>
        {
            TimerText.text = "TIME: " + (int)New;
            if(TimeLeft.Value <= 0)
            {
                StartTimer = false;
                EndGameRPC();
            }
        };
    }

    // Update is called once per frame
    void Update()
    {
        if (StartTimer)
        {
            TimeLeft.Value -= Time.deltaTime;
        }
    }
    [Rpc(SendTo.Server)]
    private void EndGameRPC()
    {
        MyUI.EnableEndGameUIRPC();
        EnemySpawn.StopSpawn();
    }
}
