
using Unity.Netcode;
using UnityEngine;

public class Projectile : NetworkBehaviour
{
    Rigidbody2D RB2D;
    NetworkObject MyNetworkObject;
    [SerializeField] private float Speed = 10f;
    [SerializeField] int Damage;
    private void FixedUpdate()
    {
        //transform.position += transform.up * Speed * Time.deltaTime;
        if(transform.position.y > 12)
        {
            OnDestroyProjectile();
        }
    }
    //On Collision Destroy Self & Damage Enemy
    private void Awake()
    {
        //Fire projectile upwards
        RB2D = GetComponent<Rigidbody2D>();
        MyNetworkObject = GetComponent<NetworkObject>();
        if(RB2D == null)
        {
            Debug.Log("No RigidBody2D Detected");
        }
        //RB2D.bodyType = RigidbodyType2D.Dynamic;
        RB2D.velocity = Vector2.up * Speed;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            collision.gameObject.GetComponent<Enemy>().TakeDamage(Damage);
            OnDestroyProjectile();
        }
    }
    private void OnDestroyProjectile()
    {
        MyNetworkObject.Despawn();
    }
}
