using System.Collections;
using Unity.Netcode;
using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    [SerializeField] Enemy MyEnemy;
    private Timer MyTimer;
    private bool Spawning = false;

    // Start is called before the first frame update
    void Start()
    {
        MyTimer = FindAnyObjectByType<Timer>();
    }

    // Update is called once per frame
    void Update()
    {
        if(MyTimer.TimeLeft.Value <= 0)
        {
            StopSpawn();
        }
    }
    public void StartSpawn()
    {
        Spawning = true;
        StartCoroutine(SpawnEnemies());
    }
    public void StopSpawn()
    {
        gameObject.SetActive(false);
    }
    IEnumerator SpawnEnemies()
    {
        if(MyTimer.TimeLeft.Value > 0 && Spawning)
        {
            yield return new WaitForSeconds(Random.Range((int)1, (int)5));
            var MyEnemyNO = Instantiate(MyEnemy, new Vector2(-5f, 6f), new Quaternion(0f, 0f, 0f, 0f)).GetComponent<NetworkObject>();
            if(MyTimer.TimeLeft.Value > 0)
            {
                MyEnemyNO.Spawn();
                StartCoroutine(SpawnEnemies());
            }
        }
    }
}
