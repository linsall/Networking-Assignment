

using System.Collections;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class Enemy : NetworkBehaviour
{
    [SerializeField] private NetworkVariable<int> Health;
    [SerializeField] private TextMeshPro HealthText;
    [SerializeField] private GameObject Projectile;
    [SerializeField] private Vector3 EndPos;
    [SerializeField] private float Speed = 5f;

    private GameObject TextObject;
    private Rigidbody2D RB2D;
    private UI MyUI;
    private Timer MyTimer;
    private Vector3 StartPos;
    private Vector3 CurrPos;
    private Vector3 TargetPos;

    private void Start()
    {
        MyTimer = FindAnyObjectByType<Timer>();
        RB2D = GetComponent<Rigidbody2D>();
        MyUI = GameObject.Find("GameCanvas").GetComponent<UI>();

        HealthText.text = Health.Value.ToString();
        StartPos = transform.position;
        Health.OnValueChanged += (oldVal, newVal) =>
        {
            HealthText.text = newVal.ToString();
            if(Health.Value <= 0)
            {
                OnDeathEnemy();
            }
        };
    }
    private void OnDeathEnemy()
    {
        MyUI.OnEnemyDeathRPC();
        GetComponent<NetworkObject>().Despawn();
    }
    private void FixedUpdate()
    {
        //Move Enemy between 2 points
        CurrPos = transform.position;
        transform.position = Vector3.MoveTowards(CurrPos, TargetPos, Speed * Time.deltaTime);
        if(CurrPos == StartPos)
        {
            TargetPos = EndPos;
        }
        else if(CurrPos == EndPos){
            TargetPos = StartPos;
        }
        if(MyTimer.TimeLeft.Value <= 0 && gameObject.activeSelf==true)
        {
            GetComponent<NetworkObject>().Despawn();
        }
    }
    public void TakeDamage(int Damage)
    {
        Health.Value -= Damage;
    }
}
