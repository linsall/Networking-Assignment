using System;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class Player : NetworkBehaviour
{

    [SerializeField] private InputReader MyInputReader;
    [SerializeField] private GameObject ObjectToSpawn;
    [SerializeField] private float Speed = 10f;
    NetworkVariable<Vector2> MoveInput = new NetworkVariable<Vector2>();
    private Timer MyTimer;

    void Start()
    {
        MyTimer = FindAnyObjectByType<Timer>();
        if(MyInputReader != null && IsLocalPlayer)
        {
            MyInputReader.MoveEvent += MoveRPC;
            MyInputReader.ShootEvent += SpawnRPC;
        }
    }
    private void OnMove(Vector2 Input)
    {
        MoveRPC(Input);
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        if (IsServer)
        {
            transform.position += (Vector3)MoveInput.Value * Speed * Time.deltaTime;
        }
        if(MyTimer.TimeLeft.Value <= 0)
        {
            GetComponent<NetworkObject>().Despawn();
        }
    }
    [Rpc(SendTo.Server)]
    private void MoveRPC(Vector2 Data)
    {
        MoveInput.Value = Data;
    }
    [Rpc(SendTo.Server)]
    private void SpawnRPC()
    {
        NetworkObject ob = Instantiate(ObjectToSpawn).GetComponent<NetworkObject>();
        ob.gameObject.transform.position = this.transform.position;
        ob.Spawn();

    }

}
