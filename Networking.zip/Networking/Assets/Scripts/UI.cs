
using System.Runtime.CompilerServices;
using TMPro;
using Unity.Netcode;
using UnityEngine;

public class UI : NetworkBehaviour
{
    [SerializeField] private NetworkManager MyNetworkManager;
    [SerializeField] private int EnemyPoint = 10;
    [SerializeField] private TextMeshProUGUI ScoreText;
    [SerializeField] private TextMeshProUGUI FinalScoreText;
    [SerializeField] private NetworkVariable<int> Score;
    [SerializeField] private Canvas EndCanvas;
    [SerializeField] private Canvas GameCanvas;
    private SpawnEnemy EnemySpawner;
    private Timer MyTimer;
    private void Start()
    {
        MyTimer = GameObject.FindAnyObjectByType<Timer>();
        if (EnemySpawner == null && MyTimer != null)
        {
            EnemySpawner = GameObject.Find("EnemySpawner").GetComponent<SpawnEnemy>();
        }
        Score.OnValueChanged += (OldVal, NewVal) =>
        {
            Score.Value = NewVal;
            OnScoreChangeRPC();
        };
    }
    [Rpc(SendTo.Everyone)]
    public void EnableEndGameUIRPC()
    {
        EndCanvas.gameObject.SetActive(true);
        FinalScoreText.text = "Score: " + Score.Value.ToString();
        GameCanvas.gameObject.SetActive(false);
    }
    public void HostPressed()
    {
        MyNetworkManager.StartHost();
    }
    public void JoinPressed()
    {
        MyNetworkManager.StartClient();
    }
    public void QuitPressed()
    {
        Application.Quit();
    }
    public void SpawnPressed()
    {
        EnemySpawner.StartSpawn();
        MyTimer.StartTimer = true;
    }
    [Rpc(SendTo.Server)]
    public void OnEnemyDeathRPC()
    {
        Score.Value += EnemyPoint;
    }
    [Rpc(SendTo.Everyone)]
    private void OnScoreChangeRPC()
    {
        ScoreText.text = "Score: " + Score.Value.ToString();
    }
}
