using TMPro;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;


public class Chat : NetworkBehaviour
{
    [SerializeField] TextMeshProUGUI Text;
    [SerializeField] TMP_InputField MyInputField;
    [Rpc(SendTo.Server)]
    public void SubmitMessageRPC(FixedString128Bytes Message)
    {
        UpdateMessageRPC(Message);
    }
    [Rpc(SendTo.Everyone)]
    public void UpdateMessageRPC(FixedString128Bytes Message)
    {
        Text.text = "Chat: "+ Message.ToString();
    }
    public void OnSend(string message)
    {
        message = MyInputField.text;
        SubmitMessageRPC(message);
    }
}
